/* Source and licensing information for the line(s) below can be found at https://www.dreamholiday.space/modules/mautic/js/mautic.js. */
(function(w,d,t,drupalSettings,n,a,m){w['MauticTrackingObject']=n;
w[n]=w[n]||function(){(w[n].q=w[n].q||[]).push(arguments)},a=d.createElement(t),
m=d.getElementsByTagName(t)[0];a.async=1;a.src=drupalSettings.mautic.base_url;m.parentNode.insertBefore(a,m)
})(window,document,'script',drupalSettings,'mt');
mt('send', 'pageview');

/* Source and licensing information for the above line(s) can be found at https://www.dreamholiday.space/modules/mautic/js/mautic.js. */