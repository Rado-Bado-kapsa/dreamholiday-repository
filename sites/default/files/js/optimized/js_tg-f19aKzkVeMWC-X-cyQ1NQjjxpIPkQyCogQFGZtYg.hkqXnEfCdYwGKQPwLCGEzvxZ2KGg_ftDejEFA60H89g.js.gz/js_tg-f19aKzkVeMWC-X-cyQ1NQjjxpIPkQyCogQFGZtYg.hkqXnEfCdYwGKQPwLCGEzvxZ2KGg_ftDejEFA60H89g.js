/* Source and licensing information for the line(s) below can be found at https://www.dreamholiday.space/core/themes/stable/js/ajax.js. */
(function(a){a.theme.ajaxProgressBar=function(a){return a.addClass('ajax-progress ajax-progress-bar')}})(Drupal);
/* Source and licensing information for the above line(s) can be found at https://www.dreamholiday.space/core/themes/stable/js/ajax.js. */