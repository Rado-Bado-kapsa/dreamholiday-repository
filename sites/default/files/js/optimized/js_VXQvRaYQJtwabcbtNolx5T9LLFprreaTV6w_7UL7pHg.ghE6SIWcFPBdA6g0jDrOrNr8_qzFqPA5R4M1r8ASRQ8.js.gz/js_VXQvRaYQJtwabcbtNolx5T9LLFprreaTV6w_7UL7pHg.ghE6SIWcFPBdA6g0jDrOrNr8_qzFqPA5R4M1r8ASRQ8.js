/* Source and licensing information for the line(s) below can be found at https://www.dreamholiday.space/core/misc/checkbox.js. */
(function(c){c.theme.checkbox=function(){return'<input type="checkbox" class="form-checkbox"/>'}})(Drupal);
/* Source and licensing information for the above line(s) can be found at https://www.dreamholiday.space/core/misc/checkbox.js. */